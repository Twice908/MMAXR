import { describe, expect, it } from "vitest";
import * as THREE from "three";
import {
  createRaycastPicker,
  createScreenRayPicker,
} from "../src/raycast-picker.js";
import { FakeDomElement } from "./helpers/fake-dom.js";

describe("raycast pickers", () => {
  function makeScene() {
    const scene = new THREE.Scene();
    const group = new THREE.Group();
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(1, 1, 1),
      new THREE.MeshBasicMaterial(),
    );
    mesh.userData.inputId = "box:1";
    group.add(mesh);
    scene.add(group);
    return { scene, group, mesh };
  }

  it("picks a world-space object by ray", () => {
    const { scene } = makeScene();
    const picker = createRaycastPicker(scene);

    const result = picker({
      origin: new THREE.Vector3(0, 0, 3),
      direction: new THREE.Vector3(0, 0, -1),
      source: "xr-controller",
      handedness: "right",
    });

    expect(result?.target).toBe("box:1");
    expect(result?.distance).toBeGreaterThan(0);
  });

  it("walks parent objects to find inputId", () => {
    const { scene, group, mesh } = makeScene();
    group.userData.inputId = "group:1";
    const picker = createRaycastPicker(scene);

    const result = picker({
      origin: new THREE.Vector3(0, 0, 3),
      direction: new THREE.Vector3(0, 0, -1),
      source: "xr-hand",
      handedness: "left",
    });

    expect(result?.target).toBe("group:1");
    expect(result?.object).toBe(group);
    mesh.geometry.dispose();
    (mesh.material as THREE.Material).dispose();
  });

  it("returns null for a miss", () => {
    const { scene } = makeScene();
    const picker = createRaycastPicker(scene);

    expect(
      picker({
        origin: new THREE.Vector3(5, 5, 3),
        direction: new THREE.Vector3(0, 0, -1),
        source: "xr-controller",
      }),
    ).toBeNull();
  });

  it("converts screen coordinates to a camera ray", () => {
    const { scene } = makeScene();
    const camera = new THREE.PerspectiveCamera(60, 4 / 3, 0.1, 100);
    camera.position.set(0, 0, 3);
    camera.lookAt(0, 0, 0);
    camera.updateMatrixWorld();

    const dom = new FakeDomElement();
    const picker = createScreenRayPicker(camera, scene, dom);

    expect(picker(400, 300)).toBe("box:1");
  });

  it("respects an object filter", () => {
    const { scene } = makeScene();
    const picker = createRaycastPicker(scene, {
      filter: () => false,
    });

    expect(
      picker({
        origin: new THREE.Vector3(0, 0, 3),
        direction: new THREE.Vector3(0, 0, -1),
        source: "xr-controller",
      }),
    ).toBeNull();
  });
});
