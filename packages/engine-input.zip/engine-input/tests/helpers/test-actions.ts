import { vi } from "vitest";
import type { InputAction } from "@mma/engine-input";

export function createActionSink() {
  const actions: InputAction[] = [];
  const dispatch = vi.fn((action: InputAction) => {
    actions.push(action);
  });

  return {
    actions,
    dispatch,
  };
}
